import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

def plot_quantum_states(statevector):
    """
    Creates a visualization of quantum state amplitudes.
    
    Args:
        statevector: State vector of a quantum system
        
    Returns:
        Matplotlib figure
    """
    labels = [f"|{bin(i)[2:].zfill(int(np.log2(len(statevector))))}⟩" for i in range(len(statevector))]
    probabilities = np.abs(statevector)**2
    
    fig, ax = plt.subplots(figsize=(8, 4))
    bars = ax.bar(labels, probabilities, color='skyblue', alpha=0.7)
    
    # Highlight the highest probability state
    max_idx = np.argmax(probabilities)
    bars[max_idx].set_color('orange')
    
    ax.set_ylim(0, 1)
    ax.set_ylabel('Probability')
    ax.set_title('Quantum State Probabilities')
    
    return fig

def plot_measurement_bases(alice_bases, bob_bases):
    """
    Visualizes the measurement bases chosen by Alice and Bob.
    
    Args:
        alice_bases: List of Alice's bases ('Z' or 'X')
        bob_bases: List of Bob's bases ('Z' or 'X')
        
    Returns:
        Matplotlib figure
    """
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 4), sharex=True)
    
    # Convert bases to numerical values for visualization
    # Z basis = 0, X basis = 1
    alice_numeric = [0 if b == 'Z' else 1 for b in alice_bases]
    bob_numeric = [0 if b == 'Z' else 1 for b in bob_bases]
    
    # Plot Alice's bases
    ax1.stem(range(len(alice_bases)), alice_numeric, basefmt=' ')
    ax1.set_ylabel("Alice's Bases")
    ax1.set_title("Measurement Bases Selection")
    ax1.set_yticks([0, 1])
    ax1.set_yticklabels(['Z', 'X'])
    
    # Plot Bob's bases
    ax2.stem(range(len(bob_bases)), bob_numeric, basefmt=' ')
    ax2.set_ylabel("Bob's Bases")
    ax2.set_xlabel("Qubit Pair Index")
    ax2.set_yticks([0, 1])
    ax2.set_yticklabels(['Z', 'X'])
    
    # Highlight matching bases
    for i in range(len(alice_bases)):
        if alice_bases[i] == bob_bases[i]:
            ax1.axvspan(i-0.4, i+0.4, alpha=0.2, color='green')
            ax2.axvspan(i-0.4, i+0.4, alpha=0.2, color='green')
    
    plt.tight_layout()
    return fig

def plot_key_comparison(alice_results, bob_results, matching_indices):
    """
    Visualizes the comparison between Alice and Bob's key bits.
    
    Args:
        alice_results: List of Alice's measurement results
        bob_results: List of Bob's measurement results
        matching_indices: Indices where Alice and Bob used the same basis
        
    Returns:
        Matplotlib figure
    """
    # Select only the matching indices for comparison
    alice_key = [alice_results[i] for i in matching_indices]
    bob_key = [bob_results[i] for i in matching_indices]
    
    # Calculate which bits match and which don't
    matching = [alice_key[i] == bob_key[i] for i in range(len(alice_key))]
    
    # Limit to first 50 bits for clarity
    display_limit = min(50, len(alice_key))
    alice_key = alice_key[:display_limit]
    bob_key = bob_key[:display_limit]
    matching = matching[:display_limit]
    
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(12, 6), sharex=True)
    
    # Plot Alice's bits
    ax1.stem(range(len(alice_key)), alice_key, basefmt=' ', markerfmt='o', linefmt='C0-')
    ax1.set_ylabel("Alice's Bits")
    ax1.set_title("Key Comparison (Matching Bases Only)")
    ax1.set_yticks([0, 1])
    
    # Plot Bob's bits
    ax2.stem(range(len(bob_key)), bob_key, basefmt=' ', markerfmt='o', linefmt='C1-')
    ax2.set_ylabel("Bob's Bits")
    ax2.set_yticks([0, 1])
    
    # Plot matching status
    ax3.stem(range(len(matching)), matching, basefmt=' ', markerfmt='o', linefmt='C2-')
    ax3.set_ylabel("Matching")
    ax3.set_xlabel("Bit Index")
    ax3.set_yticks([0, 1])
    ax3.set_yticklabels(['Mismatch', 'Match'])
    
    # Color the background based on matching
    for i in range(len(matching)):
        if not matching[i]:
            # Highlight errors across all subplots
            ax1.axvspan(i-0.4, i+0.4, alpha=0.2, color='red')
            ax2.axvspan(i-0.4, i+0.4, alpha=0.2, color='red')
            ax3.axvspan(i-0.4, i+0.4, alpha=0.2, color='red')
    
    plt.tight_layout()
    return fig

def plot_error_rate(error_rate, threshold):
    """
    Visualizes the error rate compared to the threshold.
    
    Args:
        error_rate: Observed error rate
        threshold: Threshold for raising an alarm
        
    Returns:
        Matplotlib figure
    """
    fig, ax = plt.subplots(figsize=(8, 4))
    
    # Create a gauge-like visualization
    max_rate = max(error_rate * 1.5, threshold * 1.5, 0.5)
    
    # Define color ranges
    cmap = LinearSegmentedColormap.from_list(
        'error_cmap', 
        [(0, 'green'), (threshold/max_rate, 'yellow'), (1, 'red')]
    )
    
    # Plot the gauge
    ax.barh(0, max_rate, height=0.5, color='lightgrey', alpha=0.3)
    ax.barh(0, error_rate, height=0.5, color=cmap(error_rate/max_rate))
    
    # Add a line for the threshold
    ax.axvline(threshold, color='red', linestyle='--', alpha=0.7)
    ax.text(
        threshold, 
        0.25, 
        f'Threshold: {threshold:.1f}%', 
        rotation=90, 
        va='center', 
        ha='right', 
        color='red'
    )
    
    # Add the error rate as text
    ax.text(
        error_rate / 2, 
        0, 
        f'{error_rate*100:.2f}%', 
        ha='center', 
        va='center', 
        color='white', 
        fontweight='bold'
    )
    
    # Set labels and title
    ax.set_xlim(0, max_rate)
    ax.set_ylim(-0.5, 0.5)
    ax.set_title('Error Rate Analysis')
    ax.set_xlabel('Error Rate (%)')
    
    # Remove y-axis ticks
    ax.set_yticks([])
    
    # Convert x-axis to percentage
    ax.set_xticks(np.linspace(0, max_rate, 6))
    ax.set_xticklabels([f'{x*100:.0f}%' for x in np.linspace(0, max_rate, 6)])
    
    return fig
