import numpy as np
import pandas as pd
import random
from quantum_utils import simulate_measurements

class QKDProtocol:
    """
    Implements the Quantum Key Distribution protocol between Alice and Bob.
    """
    
    def __init__(self, num_qubits):
        """
        Initialize the QKD protocol.
        
        Args:
            num_qubits: Number of qubit pairs to be used
        """
        self.num_qubits = num_qubits
        self.alice_bases = []
        self.bob_bases = []
        self.alice_results = []
        self.bob_results = []
        self.final_key = []
        self.bases = ['Z', 'X']  # Z is computational basis, X is Hadamard basis
        
    def generate_entangled_pairs(self):
        """
        Simulates the generation of entangled qubit pairs.
        In a real system, this would involve quantum hardware.
        """
        # In our simulation, we just conceptually generate the pairs
        # Actual generation and entanglement happens in the measurement simulation
        pass
        
    def select_random_bases(self):
        """
        Alice and Bob independently select random measurement bases.
        """
        self.alice_bases = [random.choice(self.bases) for _ in range(self.num_qubits)]
        self.bob_bases = [random.choice(self.bases) for _ in range(self.num_qubits)]
        
    def perform_measurements(self, eve_intercepts=None):
        """
        Simulates the measurement of the qubits by Alice and Bob.
        
        Args:
            eve_intercepts: List of qubit indices that Eve intercepts
        """
        self.alice_results, self.bob_results = simulate_measurements(
            self.num_qubits, 
            self.alice_bases, 
            self.bob_bases, 
            eve_intercepts
        )
        
    def reconcile_bases(self):
        """
        Alice and Bob publicly share which bases they used for each qubit
        and keep only the results where they used the same basis.
        
        Returns:
            List of indices where bases matched
        """
        matching_bases_indices = [
            i for i in range(self.num_qubits) 
            if self.alice_bases[i] == self.bob_bases[i]
        ]
        return matching_bases_indices
        
    def estimate_error_rate(self, sample_size=None):
        """
        Estimate the error rate by comparing a subset of Alice and Bob's
        measurement results where they used the same basis.
        
        Args:
            sample_size: Number of bits to compare (default: 20% of matching bits)
            
        Returns:
            Tuple of (sample_indices, error_rate)
        """
        matching_indices = self.reconcile_bases()
        
        if sample_size is None:
            sample_size = max(int(len(matching_indices) * 0.2), 1)
            
        # Ensure we don't exceed the number of matching indices
        sample_size = min(sample_size, len(matching_indices))
        
        # Randomly select indices to compare
        sample_indices = random.sample(matching_indices, sample_size)
        
        # Count errors
        errors = sum(
            self.alice_results[i] != self.bob_results[i] 
            for i in sample_indices
        )
        
        # Calculate error rate
        error_rate = errors / sample_size if sample_size > 0 else 0
        
        return sample_indices, error_rate
        
    def extract_final_key(self):
        """
        Extract the final key from the remaining bits after basis reconciliation
        and error estimation.
        
        Returns:
            List representing the final key
        """
        # Get indices where bases matched
        matching_indices = self.reconcile_bases()
        
        # Get indices used for error estimation
        error_sample_indices, _ = self.estimate_error_rate()
        
        # Remove the sampled indices from the matching indices
        key_indices = [i for i in matching_indices if i not in error_sample_indices]
        
        # Extract the final key
        self.final_key = [self.alice_results[i] for i in key_indices]
        
        return self.final_key
    
    def get_measurement_results_sample(self, n=10):
        """
        Returns a sample of measurement results for display purposes.
        
        Args:
            n: Number of results to include in the sample
        
        Returns:
            Pandas DataFrame with the sample data
        """
        n = min(n, self.num_qubits)
        
        data = {
            "Qubit Pair": list(range(n)),
            "Alice's Basis": self.alice_bases[:n],
            "Alice's Result": self.alice_results[:n],
            "Bob's Basis": self.bob_bases[:n],
            "Bob's Result": self.bob_results[:n],
            "Same Basis": [self.alice_bases[i] == self.bob_bases[i] for i in range(n)],
            "Matching Results": [self.alice_results[i] == self.bob_results[i] for i in range(n)]
        }
        
        return pd.DataFrame(data)
