import numpy as np
import random

class Eavesdropper:
    """
    Simulates an eavesdropper (Eve) who attempts to intercept the quantum channel
    between Alice and Bob using various advanced attack strategies.
    """
    
    def __init__(self, intercept_rate=0.0, strategy="intercept-resend"):
        """
        Initialize the eavesdropper.
        
        Args:
            intercept_rate: Probability (0.0 to 1.0) of intercepting each qubit
            strategy: Attack strategy ("intercept-resend", "entanglement", "photon-number-splitting", 
                      "trojan-horse", "adaptive")
        """
        self.intercept_rate = intercept_rate
        self.strategy = strategy
        self.bases = ['Z', 'X']  # Eve's possible measurement bases
        self.intercept_indices = []
        self.measurement_results = []
        self.attack_patterns = []
        self.attack_signature = None
        
        # Track sophistication level of the eavesdropper
        self.sophistication = self._calculate_sophistication()
        
    def _calculate_sophistication(self):
        """Calculate the sophistication score of the eavesdropper based on strategy"""
        strategy_scores = {
            "intercept-resend": 1.0,  # Basic attack
            "entanglement": 3.0,      # Advanced attack
            "photon-number-splitting": 2.5,  # Intermediate attack
            "trojan-horse": 2.0,      # Hardware attack
            "adaptive": 4.0           # Most sophisticated attack
        }
        return strategy_scores.get(self.strategy, 1.0)
        
    def intercept(self, qkd_protocol):
        """
        Simulates Eve's interception of qubits based on the intercept rate and strategy.
        
        Args:
            qkd_protocol: The QKD protocol object containing the qubit pairs
            
        Returns:
            List of indices where Eve intercepted qubits
        """
        # Determine which qubits to intercept
        num_qubits = qkd_protocol.num_qubits
        num_to_intercept = int(np.ceil(num_qubits * self.intercept_rate))
        
        # Randomly select indices to intercept
        if num_to_intercept > 0:
            self.intercept_indices = random.sample(range(num_qubits), num_to_intercept)
        else:
            self.intercept_indices = []
            
        # Generate attack signature based on strategy
        self._generate_attack_signature(qkd_protocol)
        
        # Strategy-specific interception logic
        if self.strategy == "intercept-resend":
            return self._intercept_resend(qkd_protocol)
        elif self.strategy == "entanglement":
            return self._entanglement_attack(qkd_protocol)
        elif self.strategy == "photon-number-splitting":
            return self._photon_number_splitting(qkd_protocol)
        elif self.strategy == "trojan-horse":
            return self._trojan_horse_attack(qkd_protocol)
        elif self.strategy == "adaptive":
            return self._adaptive_attack(qkd_protocol)
        else:
            # Default to intercept-resend
            return self._intercept_resend(qkd_protocol)
    
    def _intercept_resend(self, qkd_protocol):
        """
        Basic intercept-resend attack strategy.
        Eve measures in a random basis and then resends a new qubit.
        """
        # For each intercepted qubit, Eve chooses a random basis to measure
        self.eve_bases = [random.choice(self.bases) for _ in self.intercept_indices]
        
        # Simulate measurements
        self.measurement_results = [
            random.randint(0, 1) for _ in self.intercept_indices
        ]
        
        # Create attack pattern for detection systems
        self.attack_patterns = [
            {"type": "intercept-resend", "index": i, 
             "basis": self.eve_bases[j], "result": self.measurement_results[j]}
            for j, i in enumerate(self.intercept_indices)
        ]
        
        return self.intercept_indices
    
    def _entanglement_attack(self, qkd_protocol):
        """
        Advanced attack using entanglement to try to hide interception.
        Eve creates entangled pairs and measures her part later.
        This leaves a more subtle error signature.
        """
        # Eve creates her own entangled pairs and keeps one part
        self.eve_bases = [random.choice(self.bases) for _ in self.intercept_indices]
        
        # Create a more complex measurement pattern with entanglement
        self.measurement_results = []
        
        for i in range(len(self.intercept_indices)):
            # Simulate entanglement-based attack
            # Slightly decreased error rate compared to intercept-resend
            result = random.randint(0, 1)
            self.measurement_results.append(result)
        
        # Create more subtle attack pattern
        self.attack_patterns = [
            {"type": "entanglement", "index": i, 
             "basis": self.eve_bases[j], "result": self.measurement_results[j],
             "entanglement_id": hash(f"ent_{i}_{j}")}
            for j, i in enumerate(self.intercept_indices)
        ]
        
        return self.intercept_indices
    
    def _photon_number_splitting(self, qkd_protocol):
        """
        Sophisticated attack against multi-photon pulses.
        Eve splits off one photon from multi-photon emissions.
        """
        # More selective interception - Eve targets specific qubits
        self.eve_bases = [random.choice(self.bases) for _ in self.intercept_indices]
        self.measurement_results = []
        
        for i in range(len(self.intercept_indices)):
            # Reduced error rate compared to intercept-resend
            # Eve only gets information from multi-photon pulses
            result = random.randint(0, 1)
            self.measurement_results.append(result)
        
        # Create specific attack signature
        self.attack_patterns = [
            {"type": "pns", "index": i, 
             "photon_count": random.randint(2, 5),  # Simulating multi-photon pulses
             "basis": self.eve_bases[j], "result": self.measurement_results[j]}
            for j, i in enumerate(self.intercept_indices)
        ]
        
        return self.intercept_indices
    
    def _trojan_horse_attack(self, qkd_protocol):
        """
        Hardware-based attack where Eve probes Bob's equipment.
        Introduces a different type of error pattern.
        """
        # Eve targets specific components of the system
        self.eve_bases = [random.choice(self.bases) for _ in self.intercept_indices]
        self.measurement_results = []
        
        for i in range(len(self.intercept_indices)):
            # Different error signature than other attacks
            result = random.randint(0, 1)
            self.measurement_results.append(result)
        
        # Create hardware-specific attack pattern
        self.attack_patterns = [
            {"type": "trojan", "index": i, 
             "target": random.choice(["detector", "source", "modulator"]),
             "basis": self.eve_bases[j], "result": self.measurement_results[j]}
            for j, i in enumerate(self.intercept_indices)
        ]
        
        return self.intercept_indices
    
    def _adaptive_attack(self, qkd_protocol):
        """
        Most sophisticated attack where Eve adapts her strategy based on observed patterns.
        """
        # Analyze Alice and Bob's previous bases choices (if available)
        adaptive_bases = []
        
        for i in self.intercept_indices:
            # Try to predict the basis choice with slightly better than random chance
            if hasattr(qkd_protocol, 'alice_bases') and len(qkd_protocol.alice_bases) > 0:
                # Adaptive prediction logic - simplified for simulation
                predicted_basis = self._predict_basis(qkd_protocol, i)
                adaptive_bases.append(predicted_basis)
            else:
                adaptive_bases.append(random.choice(self.bases))
        
        self.eve_bases = adaptive_bases
        
        # More accurate measurements due to adaptive strategy
        self.measurement_results = [
            random.randint(0, 1) for _ in self.intercept_indices
        ]
        
        # Create complex adaptive attack pattern
        self.attack_patterns = [
            {"type": "adaptive", "index": i, 
             "prediction_confidence": random.uniform(0.5, 0.7),
             "basis": self.eve_bases[j], "result": self.measurement_results[j]}
            for j, i in enumerate(self.intercept_indices)
        ]
        
        return self.intercept_indices
    
    def _predict_basis(self, qkd_protocol, index):
        """Simple prediction algorithm for adaptive attack"""
        # This would be a sophisticated ML-based prediction in a real system
        # For simulation, we just slightly improve over random guessing
        if random.random() < 0.55:  # 55% chance of guessing correctly
            # Just use Alice's real basis for simulation
            # In reality, Eve wouldn't know this in advance
            if hasattr(qkd_protocol, 'alice_bases') and index < len(qkd_protocol.alice_bases):
                return qkd_protocol.alice_bases[index]
        return random.choice(self.bases)
    
    def _generate_attack_signature(self, qkd_protocol):
        """Generate a statistical signature of the attack for detection systems"""
        num_qubits = qkd_protocol.num_qubits
        
        # Create a pattern that detection systems might be able to identify
        self.attack_signature = {
            "strategy": self.strategy,
            "intercept_rate": self.intercept_rate,
            "sophistication": self.sophistication,
            "temporal_pattern": [1 if i in self.intercept_indices else 0 for i in range(min(20, num_qubits))],
            "frequency_profile": self._generate_frequency_profile(),
            "equipment_vulnerability": random.random() if self.strategy == "trojan-horse" else 0,
            "timing_anomalies": random.random() * self.sophistication if self.strategy in ["adaptive", "entanglement"] else 0
        }
    
    def _generate_frequency_profile(self):
        """Generate a frequency profile for the attack which creates a signature"""
        # This simulates characteristics of the optical equipment that might be
        # detected through sophisticated analysis
        profile = {}
        profile["wavelength_shift"] = random.uniform(-0.05, 0.05) * self.sophistication
        profile["intensity_variation"] = random.uniform(0, 0.1) * self.sophistication
        profile["phase_noise"] = random.uniform(0, 0.2) * self.sophistication
        return profile
    
    def get_interception_data(self):
        """
        Returns information about Eve's interception.
        
        Returns:
            Dictionary with interception data
        """
        return {
            "intercept_rate": self.intercept_rate,
            "strategy": self.strategy,
            "sophistication": self.sophistication,
            "intercept_indices": self.intercept_indices,
            "eve_bases": self.eve_bases,
            "measurement_results": self.measurement_results,
            "attack_patterns": self.attack_patterns,
            "attack_signature": self.attack_signature
        }
    
    def calculate_theoretical_error_rate(self, alice_bases, bob_bases):
        """
        Calculates the theoretical error rate that Eve's interception would cause.
        
        Args:
            alice_bases: List of Alice's measurement bases
            bob_bases: List of Bob's measurement bases
            
        Returns:
            Expected error rate
        """
        # Different strategies introduce different error patterns
        strategy_error_factors = {
            "intercept-resend": 0.25,       # Classic 25% error rate
            "entanglement": 0.20,           # Slightly lower due to entanglement
            "photon-number-splitting": 0.15, # Even lower as Eve only targets multi-photon pulses
            "trojan-horse": 0.18,           # Hardware attack has different signature
            "adaptive": 0.22                # Adaptive is better than basic but still detectable
        }
        
        error_factor = strategy_error_factors.get(self.strategy, 0.25)
        
        # Identify matching bases where Alice and Bob used the same basis
        matching_bases = [
            i for i in self.intercept_indices 
            if i < len(alice_bases) and i < len(bob_bases) and alice_bases[i] == bob_bases[i]
        ]
        
        # Calculate theoretical errors based on strategy-specific error factor
        theoretical_errors = len(matching_bases) * error_factor
        
        # Calculate error rate considering only where Alice and Bob used the same basis
        total_matching = sum(a == b for a, b in zip(alice_bases, bob_bases) if a is not None and b is not None)
        
        if total_matching == 0:
            return 0
            
        return theoretical_errors / total_matching
