import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import random

class IntrusionDetector:
    """
    Implements advanced algorithms to detect various forms of eavesdropping in Quantum Key Distribution.
    Uses multiple detection methods including AI and statistical pattern analysis to identify
    different types of quantum channel attacks.
    """
    
    def __init__(self, method="Threshold-based", threshold=0.15, advanced_features=True):
        """
        Initialize the intrusion detector with multiple detection methods.
        
        Args:
            method: Detection method ("Threshold-based", "ML-based", "AI-ensemble", 
                    "Quantum-fingerprinting", "Timing-analysis")
            threshold: Error rate threshold for the threshold-based method
            advanced_features: Whether to enable advanced detection features
        """
        self.method = method
        self.threshold = threshold
        self.advanced_features = advanced_features
        self.models = {}
        self.detectors = []
        self.attack_history = []
        self.confidence_scores = {}
        self.detection_metadata = {}
        
        # Initialize detection methods based on the chosen method
        if "Threshold-based" in self.method:
            self._initialize_threshold_detector()
        
        if "ML-based" in self.method:
            self._initialize_ml_model()
            
        if "AI-ensemble" in self.method:
            self._initialize_ai_ensemble()
            
        if "Quantum-fingerprinting" in self.method:
            self._initialize_quantum_fingerprinting()
            
        if "Timing-analysis" in self.method:
            self._initialize_timing_analyzer()
            
        # Always initialize the pattern detector if advanced features are enabled
        if self.advanced_features:
            self._initialize_attack_pattern_detector()
    
    def _initialize_threshold_detector(self):
        """
        Initialize the simplest detection method based on error rate thresholds.
        """
        self.detectors.append({
            "name": "threshold_detector",
            "type": "statistical",
            "sensitivity": 0.5,
            "threshold": self.threshold,
            "best_for": ["intercept-resend"]
        })
    
    def _initialize_ml_model(self):
        """
        Initializes and trains the machine learning model for eavesdropping detection.
        This model is trained on simulated data of error rates with and without eavesdropping.
        """
        # For the ML model, we'll use logistic regression with more sophisticated features
        self.models["logistic"] = LogisticRegression(random_state=42, C=1.0, max_iter=1000)
        
        # Generate synthetic training data
        # Normal error rates: around 0-10%
        # Eavesdropping error rates: around 15-30%
        np.random.seed(42)
        
        # Generate error rates for normal operation
        normal_error_rates = np.random.normal(0.05, 0.03, 100)
        normal_error_rates = np.clip(normal_error_rates, 0, 0.15).reshape(-1, 1)
        normal_labels = np.zeros(100)
        
        # Generate error rates with different attack types
        intercept_resend_rates = np.random.normal(0.22, 0.05, 50)
        intercept_resend_rates = np.clip(intercept_resend_rates, 0.15, 0.5).reshape(-1, 1)
        
        entanglement_rates = np.random.normal(0.18, 0.04, 50)
        entanglement_rates = np.clip(entanglement_rates, 0.12, 0.3).reshape(-1, 1)
        
        pns_rates = np.random.normal(0.14, 0.03, 50)
        pns_rates = np.clip(pns_rates, 0.1, 0.25).reshape(-1, 1)
        
        trojan_rates = np.random.normal(0.16, 0.04, 50)
        trojan_rates = np.clip(trojan_rates, 0.12, 0.3).reshape(-1, 1)
        
        adaptive_rates = np.random.normal(0.2, 0.05, 50)
        adaptive_rates = np.clip(adaptive_rates, 0.15, 0.35).reshape(-1, 1)
        
        # Combine all attack error rates
        attack_rates = np.vstack([
            intercept_resend_rates,
            entanglement_rates,
            pns_rates,
            trojan_rates,
            adaptive_rates
        ])
        attack_labels = np.ones(250)
        
        # Combine data
        X = np.vstack([normal_error_rates, attack_rates])
        y = np.hstack([normal_labels, attack_labels])
        
        # Train the model
        self.models["logistic"].fit(X, y)
        
        self.detectors.append({
            "name": "ml_detector",
            "type": "machine_learning",
            "model": "logistic_regression",
            "sensitivity": 0.7,
            "best_for": ["intercept-resend", "entanglement"]
        })
    
    def _initialize_ai_ensemble(self):
        """
        Initializes an ensemble of AI models for more sophisticated detection.
        This ensemble combines multiple ML models to detect different attack patterns.
        """
        # Initialize a more advanced random forest model
        self.models["rf"] = RandomForestClassifier(
            n_estimators=100, 
            max_depth=10,
            random_state=42
        )
        
        # Initialize a gradient boosting model
        self.models["gb"] = GradientBoostingClassifier(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        
        # Initialize a neural network model
        self.models["nn"] = Pipeline([
            ("scaler", StandardScaler()),
            ("mlp", MLPClassifier(
                hidden_layer_sizes=(20, 10),
                activation="relu",
                solver="adam",
                alpha=0.0001,
                max_iter=1000,
                random_state=42
            ))
        ])
        
        # Generate more sophisticated training data with multiple features
        np.random.seed(42)
        
        # Number of samples
        n_normal = 200
        n_attacks = 250
        
        # Features: [error_rate, bit_flip_pattern, timing_variation, intensity_fluctuation]
        
        # Normal operation features
        normal_features = np.zeros((n_normal, 4))
        normal_features[:, 0] = np.clip(np.random.normal(0.05, 0.03, n_normal), 0, 0.15)  # Error rate
        normal_features[:, 1] = np.random.normal(0.1, 0.05, n_normal)  # Bit flip pattern
        normal_features[:, 2] = np.random.normal(0.05, 0.02, n_normal)  # Timing variation
        normal_features[:, 3] = np.random.normal(0.1, 0.05, n_normal)  # Intensity fluctuation
        normal_labels = np.zeros(n_normal)
        
        # Attack features for different attack types
        attack_features = np.zeros((n_attacks, 4))
        
        # Different attack types have different signatures
        # Intercept-resend: high error rate, moderate bit flips, low timing, moderate intensity
        idx = 0
        for i in range(50):
            attack_features[idx, 0] = np.clip(np.random.normal(0.22, 0.05), 0.15, 0.5)
            attack_features[idx, 1] = np.random.normal(0.4, 0.1)
            attack_features[idx, 2] = np.random.normal(0.2, 0.1)
            attack_features[idx, 3] = np.random.normal(0.3, 0.1)
            idx += 1
        
        # Entanglement attack: moderate error rate, low bit flips, high timing, moderate intensity
        for i in range(50):
            attack_features[idx, 0] = np.clip(np.random.normal(0.18, 0.04), 0.12, 0.3)
            attack_features[idx, 1] = np.random.normal(0.2, 0.1)
            attack_features[idx, 2] = np.random.normal(0.6, 0.15)
            attack_features[idx, 3] = np.random.normal(0.35, 0.1)
            idx += 1
            
        # PNS attack: low error rate, low bit flips, low timing, high intensity
        for i in range(50):
            attack_features[idx, 0] = np.clip(np.random.normal(0.14, 0.03), 0.1, 0.25)
            attack_features[idx, 1] = np.random.normal(0.15, 0.05)
            attack_features[idx, 2] = np.random.normal(0.1, 0.05)
            attack_features[idx, 3] = np.random.normal(0.7, 0.15)
            idx += 1
            
        # Trojan attack: moderate error rate, high bit flips, low timing, low intensity
        for i in range(50):
            attack_features[idx, 0] = np.clip(np.random.normal(0.16, 0.04), 0.12, 0.3)
            attack_features[idx, 1] = np.random.normal(0.8, 0.15)
            attack_features[idx, 2] = np.random.normal(0.15, 0.05)
            attack_features[idx, 3] = np.random.normal(0.2, 0.1)
            idx += 1
            
        # Adaptive attack: high error rate, moderate bit flips, high timing, high intensity
        for i in range(50):
            attack_features[idx, 0] = np.clip(np.random.normal(0.2, 0.05), 0.15, 0.35)
            attack_features[idx, 1] = np.random.normal(0.5, 0.15)
            attack_features[idx, 2] = np.random.normal(0.5, 0.15)
            attack_features[idx, 3] = np.random.normal(0.6, 0.15)
            idx += 1
            
        attack_labels = np.ones(n_attacks)
        
        # Combine data
        X = np.vstack([normal_features, attack_features])
        y = np.hstack([normal_labels, attack_labels])
        
        # Train all models
        for model_name, model in self.models.items():
            model.fit(X, y)
        
        self.detectors.append({
            "name": "ai_ensemble",
            "type": "ensemble",
            "models": ["random_forest", "gradient_boosting", "neural_network"],
            "sensitivity": 0.85,
            "best_for": ["adaptive", "entanglement", "photon-number-splitting"]
        })
    
    def _initialize_quantum_fingerprinting(self):
        """
        Initializes a quantum fingerprinting detector that looks for specific
        signatures in the quantum channel that are characteristic of different attacks.
        """
        # In a real system, this would involve quantum hardware analysis
        # Here we simulate the detection capabilities
        
        # Define signatures for different attack types
        self.quantum_signatures = {
            "intercept-resend": {
                "wavelength_shift_threshold": 0.02,
                "phase_coherence_loss": 0.3,
                "photon_number_statistics": "poissonian",
                "detection_efficiency": 0.8
            },
            "entanglement": {
                "wavelength_shift_threshold": 0.04,
                "phase_coherence_loss": 0.5,
                "photon_number_statistics": "sub-poissonian",
                "detection_efficiency": 0.7
            },
            "photon-number-splitting": {
                "wavelength_shift_threshold": 0.01,
                "phase_coherence_loss": 0.2,
                "photon_number_statistics": "super-poissonian",
                "detection_efficiency": 0.6
            },
            "trojan-horse": {
                "wavelength_shift_threshold": 0.05,
                "phase_coherence_loss": 0.6,
                "photon_number_statistics": "thermal",
                "detection_efficiency": 0.5
            },
            "adaptive": {
                "wavelength_shift_threshold": 0.03,
                "phase_coherence_loss": 0.4,
                "photon_number_statistics": "variable",
                "detection_efficiency": 0.7
            }
        }
        
        self.detectors.append({
            "name": "quantum_fingerprinting",
            "type": "quantum",
            "signatures": len(self.quantum_signatures),
            "sensitivity": 0.9,
            "best_for": ["entanglement", "photon-number-splitting", "trojan-horse"]
        })
    
    def _initialize_timing_analyzer(self):
        """
        Initializes a timing analysis detector that looks for timing anomalies
        in the quantum communication that could indicate sophisticated attacks.
        """
        self.timing_thresholds = {
            "jitter_threshold": 2.5,        # Nanoseconds
            "delay_threshold": 5.0,         # Nanoseconds
            "coherence_threshold": 100.0,   # Microseconds
            "repetition_rate_fluctuation": 0.05  # Percent
        }
        
        self.detectors.append({
            "name": "timing_analyzer",
            "type": "temporal",
            "threshold_count": len(self.timing_thresholds),
            "sensitivity": 0.75,
            "best_for": ["trojan-horse", "adaptive"]
        })
    
    def _initialize_attack_pattern_detector(self):
        """
        Initializes a pattern detector that analyzes historical data to identify
        complex attack patterns that might not be obvious in individual measurements.
        """
        self.pattern_features = {
            "burst_attacks": True,      # Detects bursts of attacks 
            "periodic_attacks": True,   # Detects periodic attack patterns
            "targeted_attacks": True,   # Detects attacks targeting specific qubits
            "learning_attacks": True    # Detects attacks that adapt over time
        }
        
        self.detectors.append({
            "name": "pattern_detector",
            "type": "behavioral",
            "feature_count": len(self.pattern_features),
            "sensitivity": 0.8,
            "best_for": ["adaptive"]
        })
    
    def detect_intrusion(self, error_rate, additional_data=None):
        """
        Detects potential intrusion (eavesdropping) based on error rate and optional
        additional data about the quantum channel.
        
        Args:
            error_rate: Observed error rate in the QKD protocol
            additional_data: Optional dictionary with additional metrics about the 
                            quantum channel and communication
            
        Returns:
            Boolean indicating whether intrusion was detected
        """
        # Process additional data if provided
        metadata = self._process_additional_data(additional_data) if additional_data else {}
        
        # Store for later analysis
        self.detection_metadata = metadata
        
        # Collect detection results from all enabled methods
        detection_results = []
        
        # Basic threshold detection - always performed
        threshold_detection = error_rate > self.threshold
        detection_results.append(threshold_detection)
        
        # ML-based detection
        if "ML-based" in self.method and "logistic" in self.models:
            ml_features = np.array([[error_rate]])
            ml_detection = self.models["logistic"].predict(ml_features)[0] == 1
            detection_results.append(ml_detection)
        
        # AI ensemble detection
        if "AI-ensemble" in self.method and all(m in self.models for m in ["rf", "gb", "nn"]):
            # Create feature vector from error rate and metadata
            ensemble_features = self._create_ensemble_features(error_rate, metadata)
            
            # Get predictions from all models
            rf_pred = self.models["rf"].predict(ensemble_features)[0]
            gb_pred = self.models["gb"].predict(ensemble_features)[0]
            nn_pred = self.models["nn"].predict(ensemble_features)[0]
            
            # Ensemble voting (majority)
            ensemble_detection = (rf_pred + gb_pred + nn_pred) >= 2
            detection_results.append(ensemble_detection)
        
        # Quantum fingerprinting detection
        if "Quantum-fingerprinting" in self.method and hasattr(self, 'quantum_signatures'):
            qf_detection = self._detect_quantum_fingerprint(error_rate, metadata)
            detection_results.append(qf_detection)
        
        # Timing analysis detection
        if "Timing-analysis" in self.method and hasattr(self, 'timing_thresholds'):
            timing_detection = self._detect_timing_anomalies(metadata)
            detection_results.append(timing_detection)
        
        # Attack pattern detection
        if self.advanced_features and hasattr(self, 'pattern_features'):
            # Add current data to history for pattern analysis
            self._update_attack_history(error_rate, metadata)
            
            # Analyze patterns in historical data
            pattern_detection = self._detect_attack_patterns()
            detection_results.append(pattern_detection)
        
        # Combine all detection results (if any detector signals an attack, we consider it an intrusion)
        if detection_results:
            return any(detection_results)
        else:
            # Fallback to simple threshold detection
            return error_rate > self.threshold
    
    def _process_additional_data(self, data):
        """Process and normalize additional quantum channel data"""
        metadata = {}
        
        # Process error patterns if provided
        if "error_pattern" in data:
            metadata["bit_flip_pattern"] = self._calculate_bit_flip_score(data["error_pattern"])
        else:
            metadata["bit_flip_pattern"] = random.uniform(0.1, 0.3)
        
        # Process timing information if provided
        if "timing_data" in data:
            metadata["timing_variation"] = self._calculate_timing_variation(data["timing_data"])
        else:
            metadata["timing_variation"] = random.uniform(0.05, 0.15)
        
        # Process intensity information if provided
        if "intensity_data" in data:
            metadata["intensity_fluctuation"] = self._calculate_intensity_fluctuation(data["intensity_data"])
        else:
            metadata["intensity_fluctuation"] = random.uniform(0.1, 0.2)
        
        # Process attack signature if provided (from eavesdropper)
        if "attack_signature" in data:
            metadata["attack_signature"] = data["attack_signature"]
            
            # Extract specific signature features
            sig = data["attack_signature"]
            if "frequency_profile" in sig:
                metadata["wavelength_shift"] = abs(sig["frequency_profile"].get("wavelength_shift", 0))
                metadata["intensity_variation"] = sig["frequency_profile"].get("intensity_variation", 0)
                metadata["phase_noise"] = sig["frequency_profile"].get("phase_noise", 0)
            
            metadata["timing_anomalies"] = sig.get("timing_anomalies", 0)
            metadata["equipment_vulnerability"] = sig.get("equipment_vulnerability", 0)
        
        return metadata
    
    def _calculate_bit_flip_score(self, error_pattern):
        """Calculate a score representing the bit flip pattern"""
        # In a real system, this would analyze specific patterns indicative of attacks
        if isinstance(error_pattern, list) and len(error_pattern) > 0:
            # Simple pattern analysis
            runs = 0
            for i in range(1, len(error_pattern)):
                if error_pattern[i] != error_pattern[i-1]:
                    runs += 1
            return runs / len(error_pattern)
        return 0.2  # Default value
    
    def _calculate_timing_variation(self, timing_data):
        """Calculate timing variation score from timing data"""
        # In a real system, this would analyze timing signatures
        if isinstance(timing_data, list) and len(timing_data) > 0:
            return np.std(timing_data) / np.mean(timing_data) if np.mean(timing_data) > 0 else 0
        return 0.1  # Default value
    
    def _calculate_intensity_fluctuation(self, intensity_data):
        """Calculate intensity fluctuation score from intensity data"""
        # In a real system, this would analyze intensity patterns
        if isinstance(intensity_data, list) and len(intensity_data) > 0:
            return np.std(intensity_data) / np.mean(intensity_data) if np.mean(intensity_data) > 0 else 0
        return 0.15  # Default value
    
    def _create_ensemble_features(self, error_rate, metadata):
        """Create feature vector for ensemble models"""
        features = np.zeros((1, 4))
        features[0, 0] = error_rate
        features[0, 1] = metadata.get("bit_flip_pattern", 0.2)
        features[0, 2] = metadata.get("timing_variation", 0.1)
        features[0, 3] = metadata.get("intensity_fluctuation", 0.15)
        return features
    
    def _detect_quantum_fingerprint(self, error_rate, metadata):
        """Detect attack based on quantum fingerprinting"""
        # Check for signatures characteristic of different attack types
        
        # Extract relevant metrics
        wavelength_shift = metadata.get("wavelength_shift", 0)
        phase_noise = metadata.get("phase_noise", 0)
        
        # Check against known attack signatures
        for attack_type, signature in self.quantum_signatures.items():
            if wavelength_shift > signature["wavelength_shift_threshold"]:
                return True
                
            if phase_noise > signature["phase_coherence_loss"]:
                return True
        
        return False
    
    def _detect_timing_anomalies(self, metadata):
        """Detect attacks based on timing analysis"""
        # Check for timing anomalies indicative of attacks
        timing_anomalies = metadata.get("timing_anomalies", 0)
        
        # If timing anomalies exceed our threshold, flag as an attack
        return timing_anomalies > 0.3
    
    def _update_attack_history(self, error_rate, metadata):
        """Update attack history for pattern detection"""
        # Add current data to history
        history_entry = {
            "error_rate": error_rate,
            "timestamp": random.random(),  # Simulated timestamp
            "metadata": metadata
        }
        
        self.attack_history.append(history_entry)
        
        # Limit history size
        if len(self.attack_history) > 100:
            self.attack_history = self.attack_history[-100:]
    
    def _detect_attack_patterns(self):
        """Analyze attack history to detect sophisticated attack patterns"""
        # Need sufficient history for pattern detection
        if len(self.attack_history) < 5:
            return False
            
        # Check for burst attacks (sudden spikes in error rates)
        recent_errors = [entry["error_rate"] for entry in self.attack_history[-5:]]
        if max(recent_errors) > 1.5 * np.mean(recent_errors):
            return True
            
        # For more sophisticated pattern detection, we would analyze the time
        # series data to identify periodic or adaptive attack patterns
        
        return False
    
    def identify_attack_type(self, error_rate, additional_data=None):
        """
        Attempts to identify the specific type of attack being used.
        
        Args:
            error_rate: Observed error rate in the QKD protocol
            additional_data: Optional dictionary with additional metrics
            
        Returns:
            String indicating the most likely attack type, or None if no attack detected
        """
        # Process additional data
        metadata = self._process_additional_data(additional_data) if additional_data else {}
        
        # First check if there's an attack at all
        if not self.detect_intrusion(error_rate, additional_data):
            return None
            
        # Collect evidence for different attack types
        evidence = {
            "intercept-resend": 0,
            "entanglement": 0,
            "photon-number-splitting": 0,
            "trojan-horse": 0,
            "adaptive": 0
        }
        
        # Score based on error rate
        if 0.2 <= error_rate <= 0.3:
            evidence["intercept-resend"] += 2
        elif 0.15 <= error_rate < 0.2:
            evidence["entanglement"] += 2
        elif 0.1 <= error_rate < 0.15:
            evidence["photon-number-splitting"] += 2
        elif 0.15 <= error_rate < 0.2:
            evidence["trojan-horse"] += 1
        elif error_rate >= 0.2:
            evidence["adaptive"] += 1
            
        # Score based on metadata if available
        if "attack_signature" in metadata:
            sig = metadata["attack_signature"]
            
            # If we're lucky enough to have the strategy directly
            if "strategy" in sig:
                evidence[sig["strategy"]] += 5
                
            # Score based on sophistication
            if "sophistication" in sig:
                sophistication = sig["sophistication"]
                if sophistication > 3.5:
                    evidence["adaptive"] += 3
                elif sophistication > 2.5:
                    evidence["entanglement"] += 2
                elif sophistication > 2.0:
                    evidence["photon-number-splitting"] += 2
                elif sophistication > 1.5:
                    evidence["trojan-horse"] += 2
                else:
                    evidence["intercept-resend"] += 2
                    
            # Score based on timing anomalies
            if "timing_anomalies" in sig and sig["timing_anomalies"] > 0.2:
                evidence["adaptive"] += 1
                evidence["entanglement"] += 1
                
            # Score based on equipment vulnerability
            if "equipment_vulnerability" in sig and sig["equipment_vulnerability"] > 0.3:
                evidence["trojan-horse"] += 3
                
            # Score based on frequency profile
            if "frequency_profile" in sig:
                if "intensity_variation" in sig["frequency_profile"] and sig["frequency_profile"]["intensity_variation"] > 0.05:
                    evidence["photon-number-splitting"] += 2
        
        # Return the attack type with the most evidence
        if not evidence:
            return None
        return max(evidence.items(), key=lambda x: x[1])[0]
    
    def get_detection_confidence(self, error_rate, additional_data=None):
        """
        Returns the confidence level of the intrusion detection.
        
        Args:
            error_rate: Observed error rate in the QKD protocol
            additional_data: Optional dictionary with additional metrics
            
        Returns:
            Confidence score (0.0 to 1.0)
        """
        # Process additional data
        metadata = self._process_additional_data(additional_data) if additional_data else {}
        
        # Store confidence scores for different detection methods
        confidence_scores = {}
        
        # ML-based confidence
        if "ML-based" in self.method and "logistic" in self.models:
            ml_features = np.array([[error_rate]])
            ml_confidence = self.models["logistic"].predict_proba(ml_features)[0][1]
            confidence_scores["ml"] = ml_confidence
        
        # AI ensemble confidence
        if "AI-ensemble" in self.method and all(m in self.models for m in ["rf", "gb", "nn"]):
            # Create feature vector from error rate and metadata
            ensemble_features = self._create_ensemble_features(error_rate, metadata)
            
            # Get confidence scores from all models
            rf_conf = self.models["rf"].predict_proba(ensemble_features)[0][1]
            gb_conf = self.models["gb"].predict_proba(ensemble_features)[0][1]
            nn_conf = self.models["nn"].predict_proba(ensemble_features)[0][1]
            
            # Average confidence across models
            ensemble_confidence = (rf_conf + gb_conf + nn_conf) / 3
            confidence_scores["ensemble"] = ensemble_confidence
        
        # Quantum fingerprinting confidence
        if "Quantum-fingerprinting" in self.method and "wavelength_shift" in metadata:
            # Calculate confidence based on how much the wavelength shift exceeds thresholds
            max_exceeded = 0
            for _, signature in self.quantum_signatures.items():
                wavelength_shift = metadata.get("wavelength_shift", 0)
                threshold = signature["wavelength_shift_threshold"]
                if wavelength_shift > threshold:
                    exceeded_by = (wavelength_shift - threshold) / threshold
                    max_exceeded = max(max_exceeded, exceeded_by)
            
            qf_confidence = min(0.5 + (max_exceeded * 0.5), 1.0)
            confidence_scores["quantum"] = qf_confidence
        
        # Threshold-based confidence
        if error_rate <= self.threshold:
            threshold_confidence = 0.0
        else:
            # Scale to 0.5-1.0 range based on how much it exceeds threshold
            # Max considered error is threshold + 0.15
            max_error = min(self.threshold + 0.15, 1.0)
            range_size = max_error - self.threshold
            normalized = min((error_rate - self.threshold) / range_size, 1.0)
            threshold_confidence = 0.5 + (normalized * 0.5)
        
        confidence_scores["threshold"] = threshold_confidence
        
        # Store all confidence scores
        self.confidence_scores = confidence_scores
        
        # Return the highest confidence from any method
        if confidence_scores:
            return max(confidence_scores.values())
        else:
            return threshold_confidence
            
    def get_detection_details(self):
        """
        Returns detailed information about the detection analysis.
        
        Returns:
            Dictionary with detection details
        """
        attack_type = self.identify_attack_type(
            self.detection_metadata.get("error_rate", 0), 
            self.detection_metadata
        )
        
        details = {
            "method": self.method,
            "detectors": self.detectors,
            "confidence_scores": self.confidence_scores,
            "detected_attack_type": attack_type,
            "metadata": self.detection_metadata
        }
        
        return details
