import numpy as np
import matplotlib.pyplot as plt
import io
from qiskit import QuantumCircuit
from qiskit.primitives import Sampler
from qiskit_aer import Aer, AerSimulator
from qiskit.visualization import plot_bloch_multivector, plot_histogram

def create_bell_pair():
    """
    Creates a quantum circuit that generates a Bell state (entangled qubits).
    Returns the quantum circuit.
    """
    # Create a quantum circuit with 2 qubits
    circuit = QuantumCircuit(2, 2)
    
    # Apply Hadamard gate to the first qubit
    circuit.h(0)
    
    # Apply CNOT gate with control qubit 0 and target qubit 1
    circuit.cx(0, 1)
    
    return circuit

def simulate_bell_pair():
    """
    Simulates the execution of a Bell pair circuit and returns the statevector.
    """
    # Create the Bell pair circuit
    circuit = create_bell_pair()
    
    # Simulate the circuit using AerSimulator
    simulator = AerSimulator(method='statevector')
    circuit.save_statevector()
    result = simulator.run(circuit).result()
    
    # Get the statevector
    statevector = result.data()['statevector']
    
    return statevector

def visualize_quantum_circuit():
    """
    Generates a visualization of the Bell pair quantum circuit.
    Returns the image as a bytes object.
    """
    # Create the Bell pair circuit
    circuit = create_bell_pair()
    
    # Create a figure
    fig = plt.figure(figsize=(7, 3))
    
    # Draw the circuit
    circuit.draw(output='mpl', style={'name': 'bw'})
    
    # Save figure to bytes buffer
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=150, bbox_inches='tight')
    buf.seek(0)
    plt.close(fig)
    
    return buf

def measure_in_basis(qubit_state, basis):
    """
    Simulates measuring a qubit in a specific basis (Z or X).
    
    Args:
        qubit_state: The quantum state of the qubit
        basis: 'Z' or 'X' indicating the measurement basis
        
    Returns:
        Measurement result (0 or 1)
    """
    # For simplicity, we're using a probability-based approach
    # In a real quantum simulation, we would use the proper quantum operators
    
    # Random measurement outcome following quantum probabilities
    if basis == 'Z':
        # Measure in computational basis (Z)
        result = np.random.randint(0, 2)
    else:
        # Measure in Hadamard basis (X)
        result = np.random.randint(0, 2)
    
    return result

def simulate_measurements(num_pairs, alice_bases, bob_bases, eve_intercepts=None):
    """
    Simulates the measurement of multiple entangled qubit pairs.
    
    Args:
        num_pairs: Number of qubit pairs
        alice_bases: List of Alice's measurement bases ('Z' or 'X')
        bob_bases: List of Bob's measurement bases ('Z' or 'X')
        eve_intercepts: List of indices where Eve intercepts
        
    Returns:
        alice_results, bob_results (lists of measurement outcomes)
    """
    alice_results = []
    bob_results = []
    
    # If Eve doesn't intercept any qubits
    if eve_intercepts is None:
        eve_intercepts = []
    
    for i in range(num_pairs):
        # Generate a random bit that will determine the entangled state
        # This simulates the quantum correlation of entangled qubits
        random_bit = np.random.randint(0, 2)
        
        # If Eve intercepts, there's a chance the correlation is broken
        if i in eve_intercepts:
            # Eve's measurement might disturb the state
            # 50% chance the correlation is preserved, 50% it's broken
            if np.random.random() < 0.5:
                # Eve's measurement disrupted the entanglement
                # Alice and Bob's results will be uncorrelated
                alice_result = np.random.randint(0, 2)
                bob_result = np.random.randint(0, 2)
            else:
                # Eve got lucky and the correlation was preserved
                # Alice and Bob still get correlated results
                if alice_bases[i] == bob_bases[i]:
                    alice_result = random_bit
                    bob_result = random_bit
                else:
                    alice_result = random_bit
                    bob_result = np.random.randint(0, 2)
        else:
            # No Eve, so normal QKD protocol behavior
            if alice_bases[i] == bob_bases[i]:
                # If they use the same basis, they get the same result
                alice_result = random_bit
                bob_result = random_bit
            else:
                # If they use different bases, Bob's result is random
                alice_result = random_bit
                bob_result = np.random.randint(0, 2)
        
        alice_results.append(alice_result)
        bob_results.append(bob_result)
    
    return alice_results, bob_results
