import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
import time
import pandas as pd
import random

from quantum_utils import create_bell_pair, visualize_quantum_circuit
from qkd_protocol import QKDProtocol
from eavesdropper import Eavesdropper
from detection import IntrusionDetector
from visualization import (
    plot_quantum_states, 
    plot_measurement_bases, 
    plot_key_comparison, 
    plot_error_rate
)

# Set page configuration
st.set_page_config(
    page_title="AI-Powered Quantum Key Distribution",
    page_icon="🔐",
    layout="wide"
)

# Application title and description
st.title("🔐 AI-Powered Quantum Key Distribution Simulator")
st.markdown("""
This application demonstrates quantum key distribution (QKD) principles with AI-powered 
eavesdropping detection. It simulates how two parties (Alice and Bob) can establish a secure 
key using quantum entanglement, and detect any potential eavesdropper (Eve) using advanced
machine learning techniques.
""")

# Sidebar for simulation parameters
st.sidebar.header("Simulation Parameters")

num_qubits = st.sidebar.slider(
    "Number of Qubit Pairs", 
    min_value=10, 
    max_value=500, 
    value=100,
    step=10,
    help="The number of entangled qubit pairs to generate"
)

eavesdropping_percentage = st.sidebar.slider(
    "Eavesdropping Percentage", 
    min_value=0.0, 
    max_value=100.0, 
    value=0.0,
    step=5.0,
    help="Percentage of qubits intercepted by Eve"
)

# Attack strategy selection
attack_strategy = st.sidebar.selectbox(
    "Eavesdropping Strategy",
    ["intercept-resend", "entanglement", "photon-number-splitting", "trojan-horse", "adaptive"],
    help="Type of attack strategy used by Eve"
)

# Advanced detection methods
st.sidebar.header("Detection System")

error_threshold = st.sidebar.slider(
    "Error Rate Threshold (%)", 
    min_value=5.0, 
    max_value=30.0, 
    value=15.0,
    step=1.0,
    help="Maximum acceptable error rate before raising an alarm"
)

detection_method = st.sidebar.selectbox(
    "Detection Method",
    [
        "Threshold-based", 
        "ML-based (Logistic Regression)",
        "AI-ensemble",
        "Quantum-fingerprinting",
        "All Methods (Maximum Security)"
    ],
    help="Method used to detect potential eavesdropping"
)

advanced_features = st.sidebar.checkbox(
    "Enable Advanced Detection Features", 
    value=True,
    help="Enable pattern recognition and behavioral analysis"
)

# Main simulation section
col1, col2 = st.columns([1, 1])

with col1:
    st.header("Bell State Generation")
    st.markdown("Creating entangled qubit pairs in the Bell state:")
    
    # Display the quantum circuit for Bell state generation
    circuit_image = visualize_quantum_circuit()
    st.image(circuit_image, use_container_width=True)
    
    st.markdown("""
    The circuit above creates an entangled Bell state between two qubits.
    This is the foundation of our QKD protocol, where measuring one qubit
    instantly determines the state of its entangled partner.
    """)

with col2:
    st.header("QKD Protocol Overview")
    st.markdown("""
    1. **Entanglement**: Alice generates entangled qubit pairs and sends one qubit from each pair to Bob
    2. **Measurement**: Alice and Bob independently choose random measurement bases
    3. **Basis Reconciliation**: They compare which bases they used (but not the results)
    4. **Key Extraction**: They keep only the bits where they used the same basis
    5. **Error Detection**: They check a subset of bits to detect potential eavesdropping
    6. **Final Key**: If no intrusion is detected, they use the remaining bits as their secret key
    """)
    
    # Add attack strategy description
    if attack_strategy == "intercept-resend":
        st.info("""
        **Intercept-Resend Attack:**
        The most basic quantum attack where Eve measures qubits in transit and sends new ones to Bob.
        This introduces a 25% error rate when Alice and Bob use the same basis, making it relatively
        easy to detect with basic error rate analysis.
        """)
    elif attack_strategy == "entanglement":
        st.info("""
        **Entanglement Attack:**
        A more sophisticated attack where Eve creates her own entangled pairs, sending one qubit
        to Bob while keeping the other. This creates a more subtle error pattern and requires
        advanced detection methods like timing analysis and quantum fingerprinting.
        """)
    elif attack_strategy == "photon-number-splitting":
        st.info("""
        **Photon Number Splitting Attack:**
        A sophisticated attack targeting multi-photon pulses. Eve extracts one photon from
        each pulse containing multiple photons, allowing her to measure it without disturbing
        the remaining photons sent to Bob. This produces a lower error rate, making it harder to detect.
        """)
    elif attack_strategy == "trojan-horse":
        st.info("""
        **Trojan Horse Attack:**
        A hardware-based attack where Eve probes Bob's quantum equipment, introducing a distinct
        error pattern different from other attacks. Detection requires specialized monitoring
        of equipment behavior and timing analysis.
        """)
    elif attack_strategy == "adaptive":
        st.info("""
        **Adaptive Attack:**
        The most sophisticated attack where Eve adapts her strategy based on observed patterns.
        She attempts to predict Alice and Bob's basis choices with better-than-random accuracy.
        Detection requires advanced AI ensemble methods and pattern recognition algorithms.
        """)

# Start simulation button
if st.button("Run QKD Simulation", type="primary"):
    with st.spinner("Running quantum simulation..."):
        # Initialize progress
        progress_bar = st.progress(0)
        
        # Initialize the protocol
        qkd = QKDProtocol(num_qubits)
        eve = Eavesdropper(intercept_rate=eavesdropping_percentage/100, strategy=attack_strategy)
        
        # Initialize the chosen detection method
        if detection_method == "All Methods (Maximum Security)":
            selected_method = "Threshold-based, ML-based, AI-ensemble, Quantum-fingerprinting, Timing-analysis"
        else:
            selected_method = detection_method
        
        detector = IntrusionDetector(method=selected_method, threshold=error_threshold/100, advanced_features=advanced_features)
        
        # Step 1: Generate entangled qubit pairs
        progress_bar.progress(10)
        st.subheader("Step 1: Generating Entangled Qubit Pairs")
        qkd.generate_entangled_pairs()
        st.success(f"✅ Generated {num_qubits} entangled qubit pairs")
        
        # Step 2: Select random measurement bases
        progress_bar.progress(20)
        st.subheader("Step 2: Selecting Random Measurement Bases")
        qkd.select_random_bases()
        
        # Visualize the first few measurement bases
        fig_bases = plot_measurement_bases(qkd.alice_bases[:10], qkd.bob_bases[:10])
        st.pyplot(fig_bases)
        st.success("✅ Alice and Bob have selected their measurement bases")
        
        # Step 3: Eve's eavesdropping (if enabled)
        progress_bar.progress(40)
        st.subheader("Step 3: Potential Eavesdropping")
        
        if eavesdropping_percentage > 0:
            intercepted_indices = eve.intercept(qkd)
            attack_info = eve.get_interception_data()
            
            st.warning(f"⚠️ Eve intercepted {len(intercepted_indices)} qubit pairs ({eavesdropping_percentage}%) using {attack_strategy} strategy")
            
            # Display attack sophistication level
            sophistication = attack_info.get("sophistication", 1.0)
            st.progress(min(sophistication / 4.0, 1.0), f"Attack sophistication level: {sophistication:.1f}/4.0")
            
            # Show sample of intercepted qubits
            if len(intercepted_indices) > 0:
                sample_size = min(5, len(intercepted_indices))
                sample_indices = intercepted_indices[:sample_size]
                
                # Prepare sample data
                sample_data = {
                    "Qubit Index": sample_indices,
                    "Eve's Basis": [attack_info["eve_bases"][i] for i in range(sample_size)],
                    "Eve's Result": [attack_info["measurement_results"][i] for i in range(sample_size)]
                }
                
                st.markdown("**Sample of Eve's intercepted qubits:**")
                st.dataframe(pd.DataFrame(sample_data))
        else:
            st.success("✅ No eavesdropping in this simulation")
        
        # Step 4: Quantum measurements
        progress_bar.progress(60)
        st.subheader("Step 4: Performing Quantum Measurements")
        
        # Define intercepted indices variable if not defined yet
        if eavesdropping_percentage == 0:
            intercepted_indices = []
            
        qkd.perform_measurements(eve_intercepts=intercepted_indices if eavesdropping_percentage > 0 else None)
        
        # Show measurement results
        st.markdown("**Sample of measurement results:**")
        results_df = qkd.get_measurement_results_sample(10)
        st.dataframe(results_df)
        st.success("✅ Alice and Bob have measured their qubits")
        
        # Step 5: Basis reconciliation
        progress_bar.progress(70)
        st.subheader("Step 5: Basis Reconciliation")
        matching_bases = qkd.reconcile_bases()
        matching_percentage = len(matching_bases) / num_qubits * 100
        
        st.markdown(f"Alice and Bob used the same basis in {len(matching_bases)} cases ({matching_percentage:.1f}%)")
        st.success("✅ Basis reconciliation complete")
        
        # Step 6: Error rate estimation and eavesdropping detection
        progress_bar.progress(80)
        st.subheader("Step 6: Error Detection and Analysis")
        
        error_sample, error_rate = qkd.estimate_error_rate()
        
        # Theoretical error rate if Eve is present
        if eavesdropping_percentage > 0:
            theoretical_error = eve.calculate_theoretical_error_rate(qkd.alice_bases, qkd.bob_bases)
            st.info(f"Theoretical error rate from this attack: {theoretical_error*100:.2f}%")
        
        # Visualize error rate
        fig_error = plot_error_rate(error_rate, error_threshold/100)
        st.pyplot(fig_error)
        
        # Prepare additional data for advanced detection
        additional_data = {}
        if eavesdropping_percentage > 0:
            additional_data["attack_signature"] = eve.get_interception_data().get("attack_signature", {})
            additional_data["error_pattern"] = [
                qkd.alice_results[i] != qkd.bob_results[i] for i in matching_bases[:50]
            ]
        
        # Perform intrusion detection with additional data
        intrusion_detected = detector.detect_intrusion(error_rate, additional_data)
        
        # Display detection confidence
        detection_confidence = detector.get_detection_confidence(error_rate, additional_data)
        
        # Display confidence meter
        confidence_color = "red" if detection_confidence > 0.7 else "orange" if detection_confidence > 0.4 else "green"
        st.markdown(f"**Detection confidence:** {detection_confidence*100:.1f}%")
        st.progress(detection_confidence, f"Confidence level: {detection_confidence*100:.1f}%")
        
        # Identify attack type if intrusion detected
        if intrusion_detected and detection_method == "All Methods (Maximum Security)":
            detected_attack = detector.identify_attack_type(error_rate, additional_data)
            if detected_attack:
                st.markdown(f"**Detected attack type:** {detected_attack}")
                
                # Show if the detected attack matches the actual attack
                if eavesdropping_percentage > 0:
                    if detected_attack == attack_strategy:
                        st.success("✅ Attack correctly identified!")
                    else:
                        st.warning(f"⚠️ Attack misidentified. Actual: {attack_strategy}")
        
        # Step 7: Final key extraction or security alarm
        progress_bar.progress(90)
        st.subheader("Step 7: Final Key Extraction")
        
        if intrusion_detected:
            st.error("🚨 SECURITY ALERT: Potential eavesdropping detected! Key exchange aborted.")
            st.markdown(f"Measured error rate: {error_rate*100:.2f}% with detection confidence of {detection_confidence*100:.1f}%")
            
            # Show comparison between Alice and Bob's bits to visualize errors
            st.markdown("**Error visualization - differences between Alice and Bob's bits:**")
            comparison_fig = plot_key_comparison(qkd.alice_results, qkd.bob_results, matching_bases)
            st.pyplot(comparison_fig)
            
            # Show detailed detection information
            if detection_method == "All Methods (Maximum Security)" and advanced_features:
                st.markdown("**Detailed detection analysis:**")
                detection_details = detector.get_detection_details()
                
                # Display which detectors were triggered
                st.markdown("**Detection methods triggered:**")
                for detector_info in detection_details.get("detectors", []):
                    name = detector_info.get("name", "Unknown")
                    sensitivity = detector_info.get("sensitivity", 0)
                    best_for = ", ".join(detector_info.get("best_for", ["Unknown"]))
                    
                    st.markdown(f"- **{name}** (Sensitivity: {sensitivity*100:.0f}%, Best for: {best_for})")
                
                # Display confidence scores from different methods
                confidence_data = []
                for method, score in detection_details.get("confidence_scores", {}).items():
                    confidence_data.append({"Method": method, "Confidence": f"{score*100:.1f}%"})
                
                if confidence_data:
                    st.dataframe(pd.DataFrame(confidence_data))
            
        else:
            final_key = qkd.extract_final_key()
            st.success(f"✅ Secure key successfully established ({len(final_key)} bits)")
            
            # Display part of the final key
            key_display_length = min(20, len(final_key))
            st.markdown(f"**First {key_display_length} bits of the final key:**")
            st.code(''.join(str(bit) for bit in final_key[:key_display_length]))
            
            # Visualize the final key as a bit pattern
            st.markdown("**Final key visualization:**")
            fig, ax = plt.subplots(figsize=(10, 2))
            ax.imshow([final_key], cmap='binary', aspect='auto')
            ax.set_yticks([])
            st.pyplot(fig)
        
        # Completion
        progress_bar.progress(100)
        st.balloons()

st.markdown("---")
st.header("The Science Behind QKD")

# Create two columns for the science explanation
sci_col1, sci_col2 = st.columns([1, 1])

with sci_col1:
    st.subheader("Quantum Key Distribution")
    st.markdown("""
    QKD uses quantum mechanics principles to establish a secure communication channel between two parties.
    The security of QKD is based on the fundamental properties of quantum mechanics:

    1. **Quantum Superposition**: Qubits can exist in multiple states simultaneously
    2. **Quantum Entanglement**: Entangled particles share correlated properties
    3. **No-Cloning Theorem**: Quantum information cannot be perfectly copied
    4. **Measurement Effect**: Measuring a quantum system disturbs it
    """)

with sci_col2:
    st.subheader("Advanced Eavesdropping Detection")
    st.markdown("""
    Any attempt by an eavesdropper to intercept the quantum channel will introduce disturbances. 
    This is a direct consequence of quantum mechanics - Eve cannot measure the qubits without disturbing their states.

    Our advanced AI detection system uses multiple approaches:
    
    1. **Error Pattern Analysis**: Examines statistical patterns in the errors
    2. **Quantum Fingerprinting**: Detects unique signatures of different attack types
    3. **Machine Learning Ensemble**: Combines multiple AI models for higher accuracy
    4. **Temporal Analysis**: Looks for timing anomalies indicative of attacks
    5. **Behavioral Pattern Recognition**: Identifies sophisticated adaptive attacks
    """)

st.markdown("---")
st.header("Attack Strategies and Detection Methods")

# Create a dataframe to show attack types and their characteristics
attack_data = {
    "Attack Type": [
        "Intercept-Resend",
        "Entanglement",
        "Photon-Number-Splitting",
        "Trojan Horse",
        "Adaptive"
    ],
    "Sophistication": [
        "Low (1.0/4.0)",
        "High (3.0/4.0)",
        "Medium (2.5/4.0)",
        "Medium (2.0/4.0)",
        "Very High (4.0/4.0)"
    ],
    "Error Rate": [
        "High (~25%)",
        "Medium (~20%)",
        "Low (~15%)",
        "Medium (~18%)",
        "Medium-High (~22%)"
    ],
    "Best Detection Methods": [
        "Basic Threshold",
        "Quantum Fingerprinting, AI Ensemble",
        "Quantum Fingerprinting",
        "Timing Analysis, Equipment Monitoring",
        "AI Ensemble, Pattern Recognition"
    ]
}

attack_df = pd.DataFrame(attack_data)
st.dataframe(attack_df)

st.markdown("""
### Real-World Implications

Quantum Key Distribution offers a theoretical method for secure communication that is resistant to
computational attacks, including those from quantum computers. However, practical QKD systems
can be vulnerable to various side-channel attacks targeting implementation flaws rather than 
the underlying quantum mechanics.

The advanced detection methods demonstrated in this simulation would be critical components
of any real-world quantum cryptography system, helping to identify and mitigate sophisticated
eavesdropping attempts.
""")

# Add a new section on ethical frameworks and societal implications
st.markdown("---")
st.header("Ethical Framework and Societal Impact")

ethics_col1, ethics_col2 = st.columns([1, 1])

with ethics_col1:
    st.subheader("Democratizing Security")
    st.markdown("""
    As security and surveillance technologies increasingly become privatized, there's a risk that
    protection becomes available only to those who can afford it, while surveillance capabilities
    concentrate in the hands of powerful entities.
    
    **Principles for Democratic Security:**
    
    1. **Open Access**: Security technologies should be accessible to all, not just powerful institutions
    2. **Transparency**: The capabilities and limitations of security systems should be publicly documented
    3. **Community Governance**: Security standards should be developed with broad stakeholder input
    4. **Protection Against Abuse**: Technologies should incorporate safeguards against misuse
    5. **Educational Empowerment**: Knowledge about security should be widely shared
    """)

with ethics_col2:
    st.subheader("Countering Surveillance Capitalism")
    st.markdown("""
    The privatization of security and surveillance creates markets that profit from undermining
    privacy and autonomy. Quantum communication can serve as a counterbalance by:
    
    1. **Enabling Detection**: Helping ordinary people detect when they're under surveillance
    2. **Creating Accountability**: Making surveillance more technically difficult and expensive
    3. **Supporting Privacy as a Right**: Providing technical means to enforce privacy rights
    4. **Fostering Trust**: Building communication systems based on verified security rather than trust
    5. **Democratizing Protection**: Making advanced security accessible through open-source implementation
    """)

st.markdown("""
### Beyond Security: Communication for Human Flourishing

The ultimate goal of secure communication should not be merely to protect secrets, but to enable
human connection, collaboration, and creativity without fear of exploitation or control.

When people can communicate freely without fear of surveillance, they can:
- Organize for positive social change
- Share knowledge and innovations freely
- Build communities based on authentic connection
- Express themselves without self-censorship
- Collaborate across borders on global challenges

This simulator is a small step toward a future where secure communication is a public good,
not a private commodity—where technology serves human flourishing rather than control.
""")

# Add demonstration of secure communication
st.markdown("---")
st.header("Practical Application: Secure Messaging")

# Function to encrypt/decrypt with XOR (simplified for demonstration)
def xor_encrypt_decrypt(message, key):
    # Convert message to binary
    binary_message = ''.join(format(ord(char), '08b') for char in message)
    
    # Ensure the key is long enough (in a real system, the key would be expanded properly)
    binary_key = ''.join(str(bit) for bit in key)
    if len(binary_key) < len(binary_message):
        binary_key = binary_key * (len(binary_message) // len(binary_key) + 1)
    binary_key = binary_key[:len(binary_message)]
    
    # XOR operation
    result = ''
    for i in range(len(binary_message)):
        result += '1' if binary_message[i] != binary_key[i] else '0'
    
    # Convert back to characters (for display purposes)
    result_bytes = [result[i:i+8] for i in range(0, len(result), 8)]
    encrypted_chars = [chr(int(byte, 2)) for byte in result_bytes]
    
    return ''.join(encrypted_chars)

# Example communication scenario
st.subheader("Demonstration: Secure Communication Channel")

comm_col1, comm_col2 = st.columns([1, 1])

with comm_col1:
    st.markdown("### Alice's Terminal")
    
    # Get a sample key (for demonstration)
    sample_key = [random.randint(0, 1) for _ in range(64)]
    
    # Display the key as binary
    st.markdown("**Generated Quantum Key:**")
    key_display = ''.join(str(bit) for bit in sample_key[:32]) + "..."
    st.code(key_display)
    
    # Get message from user
    message = st.text_input("Enter a message to encrypt:", "The revolution will not be privatized.", key="alice_message_1")
    
    if message:
        # Encrypt the message
        encrypted_message = xor_encrypt_decrypt(message, sample_key)
        
        st.markdown("**Encrypted Message (sending through insecure channel):**")
        st.code(repr(encrypted_message))
        
        # Set session state for Bob's side
        if 'message' not in st.session_state:
            st.session_state.message = message
        if 'encrypted_message' not in st.session_state:
            st.session_state.encrypted_message = encrypted_message
        if 'key' not in st.session_state:
            st.session_state.key = sample_key

with comm_col2:
    st.markdown("### Bob's Terminal")
    
    # Display received encrypted message
    st.markdown("**Received Encrypted Message:**")
    if 'encrypted_message' in st.session_state:
        st.code(repr(st.session_state.encrypted_message))
    else:
        st.code("Waiting for message...")
    
    # Show decryption with key
    if 'encrypted_message' in st.session_state and 'key' in st.session_state:
        st.markdown("**Decryption with Quantum Key:**")
        decrypted = xor_encrypt_decrypt(st.session_state.encrypted_message, st.session_state.key)
        st.code(decrypted)
        
        # Check if Eve is present (for demonstration)
        if eavesdropping_percentage > 0:
            st.error("🚨 Warning: Eavesdropping detected on quantum channel! Key security may be compromised.")
            st.markdown("""
            Since intrusion was detected during key distribution, this key should not be trusted.
            In a real QKD system, Alice and Bob would abort this key and start a new exchange.
            """)
        else:
            st.success("✅ Message securely received and decrypted with quantum-generated key")

# Add an explanation
st.markdown("""
### How Secure Messaging Works with QKD

In a real implementation of quantum-secured communication:

1. **Key Generation**: Alice and Bob first use QKD to establish a shared secret key
2. **Intrusion Detection**: They verify no eavesdropping occurred during key distribution
3. **Symmetric Encryption**: They use the quantum-generated key with traditional encryption algorithms 
   (like AES) to encrypt their messages
4. **Secure Communication**: The encrypted messages can be sent over any communication channel
5. **Regular Key Renewal**: The quantum key is regularly refreshed to maintain security

This ensures that even if an adversary captures the encrypted messages, they cannot decrypt them without
the quantum-generated key, which cannot be intercepted without detection.

**Key difference from traditional encryption**: In conventional systems, security often relies on 
computational hardness (like factoring large numbers), which quantum computers may eventually break.
QKD security is based on the laws of physics, making it theoretically immune to computational attacks.
""")

# Add Resources and Further Action section
st.markdown("---")
st.header("Resources and Further Action")

# Create three columns for different types of resources
res_col1, res_col2, res_col3 = st.columns(3)

with res_col1:
    st.subheader("🛡️ Privacy Tools")
    st.markdown("""
    **Open-Source Encryption Tools:**
    * [Signal](https://signal.org/) - Encrypted messaging app
    * [Tor Browser](https://www.torproject.org/) - Anonymous browsing
    * [VeraCrypt](https://www.veracrypt.fr/) - Disk encryption software
    * [GnuPG](https://gnupg.org/) - Email and file encryption
    * [Tails OS](https://tails.boum.org/) - Privacy-focused operating system
    
    **Network Privacy:**
    * [Pi-hole](https://pi-hole.net/) - Network-level ad and tracker blocking
    * [Wireguard](https://www.wireguard.com/) - Modern VPN protocol
    * [OpenVPN](https://openvpn.net/) - SSL/TLS based VPN
    """)

with res_col2:
    st.subheader("📚 Education & Awareness")
    st.markdown("""
    **Learning Resources:**
    * [Electronic Frontier Foundation](https://www.eff.org/issues/privacy) - Digital privacy guides
    * [Privacy Tools](https://www.privacytools.io/) - Privacy tool recommendations
    * [Surveillance Self-Defense](https://ssd.eff.org/) - Tips for safer online communications
    * [How to disappear completely (album)](https://radiohead.com/library/#kid-a) - Maybe you are here to listen this
    
    **Understanding Surveillance:**
    * [Privacy International](https://privacyinternational.org/) - Global privacy research
    * [Tactical Tech](https://tacticaltech.org/) - Information politics
    * [Data Detox Kit](https://datadetoxkit.org/) - Digital privacy guide
    """)

with res_col3:
    st.subheader("🌍 Community & Action")
    st.markdown("""
    **Organizations to Support:**
    * [Access Now](https://www.accessnow.org/) - Digital rights advocacy
    * [Freedom of the Press Foundation](https://freedom.press/) - Journalism protection
    * [ACLU Privacy & Technology](https://www.aclu.org/issues/privacy-technology) - Legal advocacy
    * [Public Interest Tech](https://www.newamerica.org/pit/) - Tech for public good
    
    **Participate:**
    * [Cryptoparties](https://www.cryptoparty.in/) - Privacy skill-sharing events
    * [Internet Freedom Festival](https://internetfreedomfestival.org/) - Global gathering
    * [Open Source Community](https://opensource.org/) - Join open source development
    * [Public Lab](https://publiclab.org/) - Community environmental monitoring
    """)

st.subheader("Take The Next Step")
st.info("""
**From awareness to action:** Understanding quantum security principles is just the beginning. 
The tools, resources, and communities listed above can help you take practical steps to protect 
your privacy, support democratic technology development, and participate in building a more equitable 
digital future.

Knowledge without action changes little. The most important "encryption" is the one between 
understanding and doing. What will you do with what you've learned today?
""")

# Add demonstration of secure communication
st.markdown("---")
st.header("Practical Application: Secure Messaging")

# Function to encrypt/decrypt with XOR (simplified for demonstration)
def xor_encrypt_decrypt(message, key):
    # Convert message to binary
    binary_message = ''.join(format(ord(char), '08b') for char in message)
    
    # Ensure the key is long enough (in a real system, the key would be expanded properly)
    binary_key = ''.join(str(bit) for bit in key)
    if len(binary_key) < len(binary_message):
        binary_key = binary_key * (len(binary_message) // len(binary_key) + 1)
    binary_key = binary_key[:len(binary_message)]
    
    # XOR operation
    result = ''
    for i in range(len(binary_message)):
        result += '1' if binary_message[i] != binary_key[i] else '0'
    
    # Convert back to characters (for display purposes)
    result_bytes = [result[i:i+8] for i in range(0, len(result), 8)]
    encrypted_chars = [chr(int(byte, 2)) for byte in result_bytes]
    
    return ''.join(encrypted_chars)

# Example communication scenario
st.subheader("Demonstration: Secure Communication Channel")

comm_col1, comm_col2 = st.columns([1, 1])

with comm_col1:
    st.markdown("### Alice's Terminal")
    
    # Get a sample key (for demonstration)
    sample_key = [random.randint(0, 1) for _ in range(64)]
    
    # Display the key as binary
    st.markdown("**Generated Quantum Key:**")
    key_display = ''.join(str(bit) for bit in sample_key[:32]) + "..."
    st.code(key_display)
    
    # Get message from user
    message = st.text_input("Enter a message to encrypt:", "The revolution will not be privatized.", key="alice_message_2")
    
    if message:
        # Encrypt the message
        encrypted_message = xor_encrypt_decrypt(message, sample_key)
        
        st.markdown("**Encrypted Message (sending through insecure channel):**")
        st.code(repr(encrypted_message))
        
        # Set session state for Bob's side
        if 'message' not in st.session_state:
            st.session_state.message = message
        if 'encrypted_message' not in st.session_state:
            st.session_state.encrypted_message = encrypted_message
        if 'key' not in st.session_state:
            st.session_state.key = sample_key

with comm_col2:
    st.markdown("### Bob's Terminal")
    
    # Display received encrypted message
    st.markdown("**Received Encrypted Message:**")
    if 'encrypted_message' in st.session_state:
        st.code(repr(st.session_state.encrypted_message))
    else:
        st.code("Waiting for message...")
    
    # Show decryption with key
    if 'encrypted_message' in st.session_state and 'key' in st.session_state:
        st.markdown("**Decryption with Quantum Key:**")
        decrypted = xor_encrypt_decrypt(st.session_state.encrypted_message, st.session_state.key)
        st.code(decrypted)
        
        # Check if Eve is present (for demonstration)
        if eavesdropping_percentage > 0:
            st.error("🚨 Warning: Eavesdropping detected on quantum channel! Key security may be compromised.")
            st.markdown("""
            Since intrusion was detected during key distribution, this key should not be trusted.
            In a real QKD system, Alice and Bob would abort this key and start a new exchange.
            """)
        else:
            st.success("✅ Message securely received and decrypted with quantum-generated key")

# Add an explanation
st.markdown("""
### How Secure Messaging Works with QKD

In a real implementation of quantum-secured communication:

1. **Key Generation**: Alice and Bob first use QKD to establish a shared secret key
2. **Intrusion Detection**: They verify no eavesdropping occurred during key distribution
3. **Symmetric Encryption**: They use the quantum-generated key with traditional encryption algorithms 
   (like AES) to encrypt their messages
4. **Secure Communication**: The encrypted messages can be sent over any communication channel
5. **Regular Key Renewal**: The quantum key is regularly refreshed to maintain security

This ensures that even if an adversary captures the encrypted messages, they cannot decrypt them without
the quantum-generated key, which cannot be intercepted without detection.

**Key difference from traditional encryption**: In conventional systems, security often relies on 
computational hardness (like factoring large numbers), which quantum computers may eventually break.
QKD security is based on the laws of physics, making it theoretically immune to computational attacks.
""")
